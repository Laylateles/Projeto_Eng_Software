public class Usuario {
    private String nome;
    private String email;
    private char[] senha;
    private String telefone;


    // Construtor
    public Usuario(String nome, String email, char[] senha,String telefone) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
    }

    // Métodos para ver e alterar os dados
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
